package com.crud.crudforlearn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudforlearnApplicationTests {

	@Test
	void contextLoads() {
	}

}
